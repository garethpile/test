package za.co.absa.pop3poller;
import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;



public class EmailReceiver_Test {
	
	public static void main(String[] args) throws MessagingException, IOException {
		
		new EmailReceiver_Test().test();
	}
	
	public void test() throws MessagingException, IOException{
		
		//List<MessageWrapper> messages = new Office365Poller().pollForMessages();
		List<MessageWrapper> messages = new LivePoller("dev-nde-system","Password01").pollForMessages();
		
		for(MessageWrapper message:messages){
			System.out.println("===============================================================");
			System.out.println("Subject:"+message.getSubject());
			System.out.println("FROM:"+message.getFrom());
			System.out.println("TO:"+message.getTo().get(0));
			System.out.println("CC:"+((message.getCc() != null && !message.getCc().isEmpty())? message.getCc().get(0):null));
			System.out.println("BODY_MIME:"+message.getMime());
			System.out.println("BODY:"+message.getBody());
			if(message.getAttachments() != null && !message.getAttachments().isEmpty()){
				for(AttachmentWrapper attach:message.getAttachments()){
					System.out.println("  ATTACMENT_MIME:"+attach.getMime());
					System.out.println("  ATTACMENT_BYTES:"+attach.getBase64Bytes());
				}
			}
		}
		System.out.println("Done");
	}
}


