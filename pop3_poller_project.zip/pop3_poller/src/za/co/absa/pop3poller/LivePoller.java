package za.co.absa.pop3poller;

import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;

import com.sun.mail.pop3.POP3SSLStore;

class LivePoller extends AbstractMessagePoller{
	
	public LivePoller(String username,String password){
		this.username = username;
		this.password = password;
	}
	
	private String username;
	private String password;
	
	@Override
	public Store getStore() throws MessagingException {
	      final Properties properties = new Properties();

	      final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

	      properties.setProperty( "mail.pop3.socketFactory.class", SSL_FACTORY);
	      properties.setProperty( "mail.pop3.socketFactory.fallback", "false");
	      properties.setProperty( "mail.pop3.port", "995");
	      properties.setProperty( "mail.pop3.socketFactory.port", "995");
	      
	      Session emailSession = Session.getDefaultInstance(properties );
	      Store store = emailSession.getStore("pop3");
	      		      
	      URLName url = new URLName("pop3", "mobile.absa.co.za", 995, "",
	              username, password);
	       
	      store = new POP3SSLStore(emailSession, url);
	      store.connect();
	      return store;
	}
}