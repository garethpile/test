package za.co.absa.pop3poller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

interface MessagePoller{
	public List<MessageWrapper> pollForMessages() throws MessagingException, IOException; 
}