package za.co.absa.pop3poller;

import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

class Office365Poller extends AbstractMessagePoller{
	@Override
	public Store getStore() throws MessagingException {
	      //create properties field
	      Properties properties = new Properties();

	      String host = "pop-mail.outlook.com";
	      properties.put("mail.pop3.host", host);
	      properties.put("mail.pop3.port", "995");
	      //properties.put("mail.pop3.starttls.enable", "true");
	      properties.put("mail.pop3.auth", "true");
	      properties.put("mail.pop3.ssl.enable", "true");
	      Session emailSession = Session.getDefaultInstance(properties);
	  
	      //create the POP3 store object and connect with the pop server
	      Store store = emailSession.getStore("pop3");

	      store.connect(host, "leansys@outlook.com", "user1pass");
	      
	      return store;
	}
}