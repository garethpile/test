package za.co.absa.pop3poller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;

import com.lowagie.text.pdf.codec.Base64;

class MockMessagePoller implements MessagePoller{
	@Override
	public List<MessageWrapper> pollForMessages()
			throws MessagingException, IOException {
		List<MessageWrapper> messages = new ArrayList<MessageWrapper>();
		
		for(int i = 0;i<5;i++){
			messages.add(createMockMessage(i));
		}
		return messages;
	}

	private MessageWrapper createMockMessage(int i) {
		
		String encodedHello = Base64.encodeBytes("HELLO".getBytes());
		
		MessageWrapper wrap = new MessageWrapper("test"+i+"@test.co.za",
				"cctest"+i+"@test.co.za",
				"test"+i+"@test.co.za",
				"",
				"HELLO"+i,
				encodedHello);
		wrap.setMime("text/plain");
		wrap.attach(encodedHello, "text/plain", "hello"+i+".txt");
		wrap.attach(encodedHello, "text/plain", "hello"+i+".txt");
		wrap.attach(encodedHello, "text/plain", "hello"+i+".txt");
		
		return wrap;
	}
}