package za.co.absa.pop3poller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Store;

import com.lowagie.text.pdf.codec.Base64;

abstract class AbstractMessagePoller implements MessagePoller {
	
abstract public Store getStore() throws NoSuchProviderException, MessagingException;

public List<MessageWrapper> pollForMessages() throws MessagingException, IOException {

	 Store store = null;
     Folder emailFolder = null;
     
	try{
				 store = getStore();
				 List<MessageWrapper> messageWrappers = new ArrayList<MessageWrapper>(); 
				 
		         // create the folder object and open it
		         emailFolder = store.getFolder("INBOX");
		         emailFolder.open(Folder.READ_WRITE);

		         // retrieve the messages from the folder in an array and print it
		         Message[] messages = emailFolder.getMessages();
		         
		         
		         for (int i = 0; i < messages.length; i++) {
		            Message message = messages[i];
		            MessageWrapper messageWrap = new MessageWrapper();	  
		            messageWrappers.add(messageWrap);
		            appendPart(messageWrap,message,null,null,false);
		            
		            message.setFlag(Flags.Flag.DELETED, true);
		            
		         }			         
		         return messageWrappers;
	}finally{
         if (emailFolder != null && emailFolder.isOpen())emailFolder.close(true);
         if(store != null && store.isConnected())store.close();
	}
}
 public void appendPart(MessageWrapper message,Object p,String mime,String name,boolean isBody) throws MessagingException, IOException {

	  if (p instanceof Message){ 
	      Message m = (Message)p;
		  Address[] a;      
	      
	      if ((a = m.getFrom()) != null) {
	         for (int j = 0; j < a.length; j++){
	        	 message.from( a[j].toString()); 
	         }
	      }
	      
	      if ((a = m.getRecipients(Message.RecipientType.TO)) != null) {
	         for (int j = 0; j < a.length; j++){
	        	 message.to( a[j].toString()); 
	         }
	      }
	      
	      if ((a = m.getRecipients(Message.RecipientType.CC)) != null) {
	         for (int j = 0; j < a.length; j++){
	        	 message.to( a[j].toString()); 
	         }
	      }
	           
	      if (m.getSubject() != null){
	     	 message.subject(m.getSubject()); 
	      }
	      
	      appendPart(message,m.getContent(),m.getContentType(),m.getFileName(),true);

      }
      else if (p instanceof Multipart) {
         Multipart mp = (Multipart) p;
         int count = mp.getCount();
         for (int i = 0; i < count; i++){
        	 if(i == 0){
        		 appendPart(message,mp.getBodyPart(i),mp.getBodyPart(i).getContentType(),mp.getBodyPart(i).getFileName(),true);
        	 }
        	 else{
        		 appendPart(message,mp.getBodyPart(i),mp.getBodyPart(i).getContentType(),mp.getBodyPart(i).getFileName(),false);
        	 }
         }
      } 
      else if (p instanceof Part) {
    	Part part = (Part) p;
		appendPart(message,part.getContent(),part.getContentType(),part.getFileName(),isBody);
      } 
      else if (p instanceof InputStream) {
         InputStream x = (InputStream) p;
         byte[] bArray = new byte[x.available()];         
         x.read(bArray);
         
         if(isBody){
         	message.setBody(Base64.encodeBytes(bArray));
         	message.setMime(mime);
         }
         else{
        	 message.attach(Base64.encodeBytes(bArray), mime, name);
         }
      }      
      else if (p instanceof String) {
	         String x = (String) p;
	         
	         if(isBody){
	         	message.setBody(Base64.encodeBytes(x.getBytes()));
	         	message.setMime(mime);
	         }
	         else{
	        	 message.attach(Base64.encodeBytes(x.getBytes()), mime, name);
	         }
	      }      
   }
}